<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/17/2022
 * Time: 8:46 PM
 */
require_once dirname(__FILE__) . "/vendor/autoload.php";
$csrf = \Http\Request::session();
$editAttr = null;

function create()
{
    $name = $_POST['name'];
    $year = $_POST['year'];

    (new \App\Models\Author())->create(

        [
            'name' => $name,
            'year' => $year
        ])->runQuery();
}

\Http\Request::handle_post('create', $csrf);


function delete()
{

    $id = $_GET['id'];
    (new \App\Models\Author())->delete()->where('id', $id)->runQuery();
}

\Http\Request::handle_delete('delete', $csrf);

function edit()
{
    global $editAttr;
    $editAttr = (new \App\Models\Author())->select()->where('id', $_GET['id'])->get();
}

\Http\Request::handle_edit('edit');

function update()
{
    (new \App\Models\Author())->update(['name' => $_POST['name'], 'year' => $_POST['year']])->where('id',$_GET['id'])->runQuery();
}

\Http\Request::handle_update('update');
$authors = (new \App\Models\Author())->all();
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Authors</title>
    <link href="dist/css/bootstrap.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Welcome To first S.Q Framework</h1>
    <h6>test 6</h6>
    <div class="row">
        <div class="   <?php
        if (isset($editAttr)) {
            echo "col-md-6";
        } else {
            echo "col-md-12";
        }
        ?>">
            <form action="author.php" method="post">
                <h3>Create An Author</h3>
                <input name="csrf" type="hidden" value="<?php echo $csrf ?>">

                <input name="method" type="hidden" value="create">
                <input type="text" name="name" class="form-control mb-3">
                <input type="number" name="year" class="form-control mb-3">
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div> <?php
        if (isset($editAttr)) {
            ?>
            <div class="col-md-6">
                <h3>Edit Author</h3>
                <form action="author.php?id=<?php echo $editAttr[0]->id; ?>" method="post">
                    <input name="csrf" type="hidden" value="<?php echo $csrf ?>">
                    <input name="method" type="hidden" value="update">
                    <input type="text" name="name" value="<?php echo $editAttr[0]->name; ?>" class="form-control mb-3">
                    <input type="number" name="year" value="<?php echo $editAttr[0]->year; ?>"
                           class="form-control mb-3">
                    <button type="submit" class="btn btn-warning">Update</button>
                </form>
            </div>
            <?php
        }
        ?>
    </div>

    <table class="table table-dark rounded ">
        <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Year</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach ($authors as $author) {

            echo "<tr>";
            echo "<td> $author->id</td>";
            echo "<td> $author->name</td>";
            echo "<td> $author->year</td>";
            echo "<form action='author.php?id=$author->id' method='post' target='_blank' >
                    <input type='hidden' name='method' value='delete'>
                    
                <td>   <button class=' btn btn-outline-danger'>Delete</button></td> 
                    </form>";
            echo "
                <form action='author.php?id=$author->id' method='post' target='_blank' >
                    <input type='hidden' name='method' value='edit'>
                    
                    <td>   
                        <button class=' btn btn-outline-warning'>Edit</button>
                     </td> 
                </form>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

<script src="dist/js/bootstrap.js" type="application/javascript"></script>
</body>
</html>
