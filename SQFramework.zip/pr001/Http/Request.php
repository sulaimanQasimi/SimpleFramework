<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/17/2022
 * Time: 9:07 PM
 */

namespace Http;

class Request
{
    public static function request_poison()
    {

    }

    /**
     * @return string
     */
    public static function session()
    {
        session_start();
        $csrf = md5(time());
        $_SESSION['csrf'] = $csrf;
        return $csrf;
    }

    // run on create

    /**
     * @param callable $function
     * @param $csrf
     * @param string $method
     */
    public static function handle_post(callable $function, &$csrf)
    {

//        $csrf = \Http\Request::session();
//        if (isset($_SESSION['csrf']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
//            if ($_SESSION['csrf'] == $_POST['csrf']) {
//                $function();
//            }
//            // Reset and destroy the session
//            session_reset();
//            session_destroy();
//
//        }
        if (isset($_POST['method']) AND $_POST['method'] == "create") {
            $function();
        }


    }

    public static function handle_delete(callable $function, &$csrf)
    {
        if (isset($_GET['id']) AND isset($_POST['method']) AND $_POST['method'] == "delete") {
            $function();
        }

    }

    public static function handle_edit(callable $function)
    {
        if (isset($_GET['id']) AND isset($_POST['method']) AND $_POST['method'] == 'edit') {
            $function();
        }

    }

    public static function handle_update(callable $function)
    {
        if (isset($_GET['id']) AND isset($_POST['method']) AND $_POST['method'] == 'update') {
            $function();
        }

    }


}