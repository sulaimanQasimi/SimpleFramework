<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/18/2022
 * Time: 8:16 PM
 */

namespace App\Extention;
class Url
{
    public $metas, $title, $body;

    public function __construct($url)
    {
        if (isset($url)){

            $html = $this->file_get_contents_curl($url);
            // Load HTML to DOM object
            $doc = new \DOMDocument();
            @$doc->loadHTML($html);

            $nodes = $doc->getElementsByTagName('title');
            $this->title = $nodes->item(0)->nodeValue;
            $this->metas = $doc->getElementsByTagName('meta');
            $this->body = $doc->getElementsByTagName('body');
        }

    }

    private function file_get_contents_curl($url)
    {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

        $data = curl_exec($ch);
        curl_close($ch);

        return $data;

    }


}