<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/16/2022
 * Time: 11:22 AM
 */

namespace App\Database;

trait Query
{
    private $dbColumn = '';


    public function __construct()
    {
        $this->dbColumn = Column::alias($this->column);
        if (method_exists($this, 'createTable')) {
            $this->createTable();
            $this->runQuery();
        } else {
            die();
        }
    }


    private $query;

    /**
     * @param string $column
     * @return object
     */
    public function select($column = '*')
    {
        $this->query = "SELECT $column FROM  $this->table ";
        return $this;
    }

    public function all(): object
    {
        $this->query = "SELECT * FROM  $this->table ";
        return (object)$this->get();
    }


    /**
     * @param string $function
     * @param string $column
     * @param null $alias
     * @return object
     */
    public function functionQuery($function = 'count', $column = 'id', $alias = null): object
    {
        // make the function name to upper case
        $function = strtoupper($function);
        // some valid functions
        $functions = ['COUNT', 'SUM', 'AVG', 'MAX', 'MIN'];
        // if alias is null then function namr became the alias
        if (is_null($alias = null)) {
            // change the function to lower case
            $alias = strtolower($function);
        } else {
            // change the alias to lower case
            $alias = strtolower($alias);
        }
        // if the function exist in array then make a query
        if (in_array($function, $functions)) {
            $this->query = "SELECT $function($column) AS $alias FROM  $this->table ";
            echo $this->query;
        } else {
            // function not found in array then print a message and stop the procedure
            echo "FUNCTION NOT FOUNDED";
            die();
        }
        // if all thing  is normal then return the class itself
        return $this;
    }


    public function between($val1, $val2, $column = 'id'): object
    {
        $this->query .= " WHERE $column BETWEEN $val1 AND $val2";
        return $this;
    }

    public function get(): array
    {
        $result = Connection::connect()->query($this->query);
        $result->setFetchMode(\PDO::FETCH_OBJ);
        return $result->fetchAll();

    }

    public function where($column, $value, $op = '=')
    {
        $oprators = ['=', '<>', '<=', '>=', '!=', 'LIKE'];

        // if the Oprator exist in array then make a query
        if (in_array($op, $oprators)) {
            $this->query .= "WHERE $column $op '$value' ";
        } else {
            // function not found in array then print a message and stop the procedure
            echo "Oprator NOT FOUNDED";
            die();
        }
        // if all thing  is normal then return the class itself
        return $this;
    }

    public function andWhere($column, $value, $op)
    {
        $oprators = ['=', '<>', '<=', '>=', '!=', 'LIKE'];

        // if the Oprator exist in array then make a query
        if (in_array($op, $oprators)) {
            $this->query .= "AND WHERE $column $op '$value' ";
        } else {
            // function not found in array then print a message and stop the procedure
            echo "Oprator NOT FOUNDED";
            die();
        }
        // if all thing  is normal then return the class itself
        return $this;
    }

    public function orWhere($column, $value, $op)
    {
        $oprators = ['=', '<>', '<=', '>=', '!=', 'LIKE'];

        // if the Oprator exist in array then make a query
        if (in_array($op, $oprators)) {
            $this->query .= "OR WHERE $column $op '$value' ";
        } else {
            // function not found in array then print a message and stop the procedure
            echo "Oprator NOT FOUNDED";
            die();
        }
        // if all thing  is normal then return the class itself
        return $this;
    }

    public function orderBy($column = 'id', $order = 'ASC')
    {
        $this->query .= "ORDER BY $column $order";
        return $this;
    }

    public function last_id()
    {
        return Connection::connect()->lastInsertId('id');
    }

    public function tables()
    {
        $this->query = "SHOW  TABLES";
        return $this->get();
    }

    public function columns()
    {
        $this->query = "SHOW COLUMNS FROM " . $this->table;
        return (object)$this->get();
    }

    public function describe()
    {
        $this->query = "DESCRIBE  " . $this->table;
        return (object)$this->get();
    }

    public function update(array $attribute)
    {
        $string = Column::compress($attribute);
        $this->query = "UPDATE $this->table SET $string";
        return $this;
    }

    public function create(array $attribute)
    {
        list($column, $value, $bind, $len) = Column::bindAttribute($attribute);
        $this->query = "INSERT INTO $this->table ($column) VALUES ($value)";
        return $this;
    }

    public function delete()
    {

        $this->query = "DELETE FROM $this->table ";
        return $this;

    }

    public function runQuery()
    {
        $db = Connection::connect();
        $db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $stmt = $db->exec($this->query);

    }


}