<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/15/2022
 * Time: 9:38 PM
 */
namespace App\Database;
class Connection
{
    private static $host = 'localhost';
    private static $username = 'root';
    private static $password = '';
    private static $database = 'test';
    public  static $connect=null;

    public static function connect()
    {
        try{
//            return new \PDO("mysql:host=".self::$host.";dbname=".self::$database,self::$username,self::$password);
            return new \PDO('sqlite:sqlite.db');
        }catch (\PDOException $e){

            return $e;
        }
    }


}