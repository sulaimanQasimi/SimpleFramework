<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/21/2022
 * Time: 10:24 PM
 */

namespace App\Database;


class Column
{
    public static function compress(array $attribute): string
    {
        $result = "";
        foreach ($attribute as $key => $value) {
            $result .= $key . " = '$value',";
        }
        $result = preg_replace('/,$/', ' ', $result);

        return $result;
    }

    public static function alias(array $attribute)
    {
        $result = "";
        foreach ($attribute as $key => $value) {
            $result .= "`$key` AS `$value`,";
        }
        $result = preg_replace('/,$/', ' ', $result);

        return $result;

    }

    public static function bindAttribute(array $attribute, $el = ':'): array
    {
        $column = '';
        $value = '';
        $bind = '';
        $len=0;
        foreach ($attribute as $key => $item) {
            $column .= "`$key` ,";
            $value .= "'$item' ,";
            $bind .= $el.$key.',';
        $len++;
        }
        $column = preg_replace('/,$/', ' ', $column);
        $value = preg_replace('/,$/', ' ', $value);
        $bind = preg_replace('/,$/', ' ', $bind);
        return array($column, $value, $bind,$len);
    }
}