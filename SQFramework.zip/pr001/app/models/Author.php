<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/15/2022
 * Time: 9:36 PM
 */

namespace App\Models;


use App\Database\Connection;
use App\Database\Query;

class Author
{
    /** only for select query
     * @var array
     */
    private $column=['name'=>"firstName","year"=>'Publish'];
    public $table = 'author';
    use Query;

    /**
     * for crud option you must define table
     */
    private function createTable()
    {
        $this->query = "
                   CREATE TABLE IF NOT  EXISTS `author` (
                      `id` INTEGER PRIMARY KEY  AUTOINCREMENT,
                      `name` varchar(255) DEFAULT NULL,
                      `year` year(4) DEFAULT NULL
                       ) ";
    }
}