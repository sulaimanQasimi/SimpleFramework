<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2/21/2022
 * Time: 11:48 PM
 */

namespace App\Models;


use App\Database\Query;

class Car
{

    private $column = ['model' => "Model", "year" => 'yeard'];
    public $table = 'cars';
    use Query;


    /**
     * for crud option you must define table
     */
    private function createTable()
    {
        $this->query = "
                    CREATE TABLE IF NOT  EXISTS `cars` (
                      `id` INTEGER PRIMARY KEY  AUTOINCREMENT,
                      `model` varchar(255) DEFAULT NULL,
                      `year` year(4) DEFAULT NULL
                       ) ";
    }

}